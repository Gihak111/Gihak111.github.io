// 4단계: 불꽃 또는 가스가 감지되면 울리는 스마트 복합 경보기

int flameSensor = 2; // 불꽃 센서: 2번 핀
int gasSensor = 3;   // 가스(연기) 센서(MQ-2): 3번 핀 (디지털 DO 핀 연결)
int ledPin = 8;      // LED: 8번 핀
int buzzerPin = 9;   // 피에조 부저: 9번 핀

void setup() {
  pinMode(flameSensor, INPUT);
  pinMode(gasSensor, INPUT); // 가스 센서도 '입력'
  pinMode(ledPin, OUTPUT);
  pinMode(buzzerPin, OUTPUT);
}

void loop() {
  int fireState = digitalRead(flameSensor); // 불꽃 상태 확인
  int gasState = digitalRead(gasSensor);    // 가스 상태 확인

  // || 기호는 '또는(OR)'을 의미합니다. (Shift + \ 키)
  // 불꽃이 감지되거나(OR) 가스가 감지되면!
  if (fireState == HIGH || gasState == HIGH) { 
    
    // 위험을 알리는 비상 작동 (깜빡이고 소리나게 응용)
    digitalWrite(ledPin, HIGH);
    tone(buzzerPin, 1000);
    delay(200); 
    
    digitalWrite(ledPin, LOW);
    tone(buzzerPin, 800); // 소리 높이를 바꿔서 사이렌처럼 연출
    delay(200);
    
  } else { 
    // 둘 다 감지되지 않은 평상시 안전 상태
    digitalWrite(ledPin, LOW);
    noTone(buzzerPin);
  }
}